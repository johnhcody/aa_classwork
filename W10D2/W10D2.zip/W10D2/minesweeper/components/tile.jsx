import React from 'react';
import { Tile } from '../minesweeper';
// import { render } from 'react-dom';
import React from 'react';


const Tile = () => {

    render() {
        return (
            <div>T</div>
        )
    }
}





export default Tile;