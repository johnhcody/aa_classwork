import React from 'react';
import Game from './game';

// import Tile from './tile';


const Root = () => {
    // debugger
    return (
        <div>
            < Game />
            <h1>Testing!</h1>
        </div>
    )
};


export default Root;