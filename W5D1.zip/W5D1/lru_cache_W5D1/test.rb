require 'byebug'

puts "debugger"
debugger
puts "hello"